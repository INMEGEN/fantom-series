package fantom4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

class Crearciondearchivos {
    
    public void generarArchivos1 ( JTable tabla , String a , String b ) throws IOException {
        String ruta = "/home/alex/Documents/Fantom4/" + b + "_regula_" + a + ".txt";
        String c = null ;
        String d = null ;
        File f = new File ( ruta );
        if ( f.exists() ) { 
            f.delete() ; 
        } else { 
            f.createNewFile() ; 
        }
        FileReader fr = new FileReader (f);
        BufferedReader br = new BufferedReader(fr);
        FileWriter w = new FileWriter(f,true);
        BufferedWriter bw = new BufferedWriter(w);
        PrintWriter wr = new PrintWriter(bw);
        for ( int i = 0 ; i < tabla.getRowCount() ; i++ ) {
            for ( int  j = 0 ; j < tabla.getColumnCount() ; j++ ) {
                if ( j == 0 ) { c = String.valueOf(tabla.getValueAt (i , j ))  ; }
                if ( j == 1 ) { d = String.valueOf(tabla.getValueAt (i , j ))  ; }
                
                
                System.out.println( "pos " + i + " " + j + " = " + tabla.getValueAt( i , j ) );
            }
            System.out.println("c = " + c );
            System.out.println("d = " + d );
            System.out.println("imprime: " + b + " , " + c + " , " + d );
            wr.printf( b + " , " + c + " , " + d + "\n");
            System.out.println("\n");
        }
        wr.close();
        bw.close();
        br.close();
        fr.close();
    }
    
    public void generarArchivos2 ( JTable tabla , String a , String b ) throws IOException {
        String ruta = "/home/alex/Documents/Fantom4/" + b + "_es_regulado_por_" + a + ".txt";
        String c = null ;
        String d = null ;
        File f = new File ( ruta );
        if ( f.exists() ) { 
            f.delete() ; 
        } else { 
            f.createNewFile() ; 
        }
        FileReader fr = new FileReader (f);
        BufferedReader br = new BufferedReader(fr);
        FileWriter w = new FileWriter(f,true);
        BufferedWriter bw = new BufferedWriter(w);
        PrintWriter wr = new PrintWriter(bw);
        for ( int i = 0 ; i < tabla.getRowCount() ; i++ ) {
            for ( int  j = 0 ; j < tabla.getColumnCount() ; j++ ) {
                if ( j == 0 ) { c = String.valueOf(tabla.getValueAt (i , j ))  ; }
                if ( j == 1 ) { d = String.valueOf(tabla.getValueAt (i , j ))  ; }
                
                
                System.out.println( "pos " + i + " " + j + " = " + tabla.getValueAt( i , j ) );
            }
            System.out.println("c = " + c );
            System.out.println("d = " + d );
            System.out.println("imprime: " + b + " , " + c + " , " + d );
            wr.printf( b + " , " + c + " , " + d + "\n");
            System.out.println("\n");
        }
        wr.close();
        bw.close();
        br.close();
        fr.close();
    }
}